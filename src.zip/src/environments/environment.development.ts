export const environment = {
  firebase: {
    projectId: 'bilblioteca-utvco',
    appId: '1:300838752133:web:ecd6a9fe2e729f3801beec',
    storageBucket: 'bilblioteca-utvco.appspot.com',
    apiKey: 'AIzaSyDUaY8_v291vDF8S2Lz4pGJcDN7J8zs6_4',
    authDomain: 'bilblioteca-utvco.firebaseapp.com',
    messagingSenderId: '300838752133',
    measurementId: 'G-1SWTNQN88V',
  },};
