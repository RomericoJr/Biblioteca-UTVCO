import { FiltBookPipe } from './filt-book.pipe';

describe('FiltBookPipe', () => {
  it('create an instance', () => {
    const pipe = new FiltBookPipe();
    expect(pipe).toBeTruthy();
  });
});
