import { Component } from '@angular/core';

@Component({
  selector: 'app-read-estadia',
  templateUrl: './read-estadia.component.html',
  styleUrls: ['./read-estadia.component.css']
})
export class ReadEstadiaComponent {

}
