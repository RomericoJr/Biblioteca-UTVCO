import { Component } from '@angular/core';

@Component({
  selector: 'app-inicio-adm',
  templateUrl: './inicio-adm.component.html',
  styleUrls: ['./inicio-adm.component.css']
})
export class InicioAdmComponent {

}
